﻿public class Launcher
{
    public static void Main()
    {
        
    }
}
